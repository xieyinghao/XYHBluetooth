//
//  ViewController.h
//  photographDemo
//
//  Created by liguohuai on 16/4/3.
//  Copyright © 2015年 Renford. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYHUIImagePickerController : UIViewController

- (void) shutterCamera;
@end

