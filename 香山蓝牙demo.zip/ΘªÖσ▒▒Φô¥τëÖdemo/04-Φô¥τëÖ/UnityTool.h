//
//  UnityTool.h
//  LingQianGuan
//
//  Created by wtjr on 16/6/12.
//  Copyright © 2016年 wtjr. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define kAPP_deviceUUID     @"kAPP_deviceUUID"

@interface UnityTool : NSObject

+ (instancetype)shareInstance;

#pragma mark - 用户信息相关
//获取UUID
- (NSString *)getUUID;

//获取UserID
- (NSString *)userId;

//判断是否登录
- (BOOL)isLogin;


#pragma mark - 计算相关
//计算利润
- (float)calculateProfitWithmoney:(float)money days:(NSUInteger)days rate:(float)rate;


#pragma mark - 金额输入处理
//处理金额输入框输入
- (BOOL)handMoneyTextField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string;

#pragma mark - RSA加密
//RSA公钥加密
+ (NSString *)encryptString:(NSString *)str publicKey:(NSString *)pubKey;

//RSA私钥解密
+ (NSString *)decryptString:(NSString *)str privateKey:(NSString *)privKey;

#pragma mark - MD5加密
//加密字符串
+ (NSString *)md5ForString:(NSString*)str;
//加密data
+ (NSString *)md5ForData:(NSData *)data;

#pragma mark - 控制器相关
//主界面pop到root控制器
+ (void)allViewControllerPopRootViewController;

#pragma mark - NSUserDefault存取值
//存储bool值
+ (void)setBoolValueForConfigurationKey:(NSString *)objectKey WithValue:(BOOL )boolvalue;

//根据字符串获取存储的bool值
+ (BOOL)getBoolValueForConfigurationKey:(NSString *)objectKey;

//存储key-value值
+ (void)setStringValueForConfigurationKey:(NSString *)objectKey WithValue:(NSString *)value;

//根据字符串获取存储的string值
+ (NSString *)getStringValueForConfigurationKey:(NSString *)objectKey;

@end
